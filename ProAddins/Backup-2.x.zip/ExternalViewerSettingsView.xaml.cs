﻿using System.Windows.Controls;

namespace ProAddins
{
    /// <summary>
    /// Interaction logic for ExternalViewerSettingsView.xaml
    /// </summary>
    public partial class ExternalViewerSettingsView : UserControl
    {
        public ExternalViewerSettingsView()
        {
            InitializeComponent();
        }
    }
}
